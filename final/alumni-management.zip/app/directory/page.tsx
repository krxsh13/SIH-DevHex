"use client"
import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/layout/footer"
import { AlumniList } from "@/components/directory/alumni-list"
import type { AlumniProfile } from "@/components/directory/alumni-card"
import { useToast } from "@/hooks/use-toast"

// Mock data - replace with real API calls
const mockAlumni: AlumniProfile[] = [
  {
    id: "1",
    name: "Priya Sharma",
    title: "Senior Software Engineer",
    company: "Flipkart",
    location: "Bangalore, Karnataka",
    graduationYear: "2020",
    industry: "Technology",
    skills: ["React", "TypeScript", "Node.js", "Python", "AWS"],
    bio: "Passionate about building scalable e-commerce platforms and mentoring junior developers. Love contributing to open source projects.",
    isConnected: false,
    isAvailableForMentorship: true,
  },
  {
    id: "2",
    name: "Arjun Patel",
    title: "Product Manager",
    company: "Paytm",
    location: "Noida, Uttar Pradesh",
    graduationYear: "2019",
    industry: "Technology",
    skills: ["Product Strategy", "Data Analysis", "Agile", "User Research"],
    bio: "Leading fintech product initiatives. Experienced in taking products from concept to millions of users across India.",
    isConnected: true,
    isAvailableForMentorship: true,
  },
  {
    id: "3",
    name: "Sneha Reddy",
    title: "Investment Banking Analyst",
    company: "ICICI Bank",
    location: "Mumbai, Maharashtra",
    graduationYear: "2021",
    industry: "Finance",
    skills: ["Financial Modeling", "Valuation", "M&A", "Excel", "PowerPoint"],
    bio: "Working in corporate banking with focus on infrastructure and manufacturing sector deals. Happy to guide students in finance careers.",
    isConnected: false,
    isAvailableForMentorship: true,
  },
  {
    id: "4",
    name: "Rohit Kumar",
    title: "UX Designer",
    company: "Zomato",
    location: "Gurgaon, Haryana",
    graduationYear: "2018",
    industry: "Design",
    skills: ["UI/UX Design", "Figma", "User Research", "Prototyping", "Design Systems"],
    bio: "Designing food-tech experiences that connect millions of Indians with their favorite restaurants. Passionate about inclusive design.",
    isConnected: false,
    isAvailableForMentorship: false,
  },
  {
    id: "5",
    name: "Kavya Nair",
    title: "Marketing Director",
    company: "Byju's",
    location: "Bangalore, Karnataka",
    graduationYear: "2017",
    industry: "Marketing",
    skills: ["Digital Marketing", "Content Strategy", "SEO", "Analytics", "Brand Management"],
    bio: "Leading growth marketing for EdTech products reaching millions of Indian students. Love helping startups scale in the Indian market.",
    isConnected: true,
    isAvailableForMentorship: true,
  },
  {
    id: "6",
    name: "Vikram Singh",
    title: "Data Scientist",
    company: "Ola",
    location: "Bangalore, Karnataka",
    graduationYear: "2020",
    industry: "Technology",
    skills: ["Machine Learning", "Python", "SQL", "Statistics", "Deep Learning"],
    bio: "Building ML models for ride-sharing optimization and demand forecasting. Excited about AI applications in mobility and logistics.",
    isConnected: false,
    isAvailableForMentorship: true,
  },
  {
    id: "7",
    name: "Ananya Gupta",
    title: "Management Consultant",
    company: "Deloitte India",
    location: "Mumbai, Maharashtra",
    graduationYear: "2019",
    industry: "Consulting",
    skills: ["Strategy", "Problem Solving", "Data Analysis", "Client Management", "Presentation"],
    bio: "Helping Indian enterprises with digital transformation and operational excellence. Specialized in manufacturing and retail sectors.",
    isConnected: false,
    isAvailableForMentorship: true,
  },
  {
    id: "8",
    name: "Rajesh Iyer",
    title: "Software Engineering Manager",
    company: "Infosys",
    location: "Chennai, Tamil Nadu",
    graduationYear: "2016",
    industry: "Technology",
    skills: ["Team Leadership", "System Design", "Java", "Kubernetes", "Microservices"],
    bio: "Leading engineering teams building enterprise software solutions. Passionate about mentoring engineers and building diverse teams.",
    isConnected: false,
    isAvailableForMentorship: true,
  },
]

export default function DirectoryPage() {
  const { toast } = useToast()

  const handleConnect = (id: string) => {
    // Simulate API call
    toast({
      title: "Connection Request Sent",
      description: "Your connection request has been sent successfully.",
    })
  }

  const handleMessage = (id: string) => {
    // Simulate navigation to messaging
    toast({
      title: "Opening Messages",
      description: "Redirecting to your conversation...",
    })
  }

  const handleViewProfile = (id: string) => {
    // Simulate navigation to profile
    toast({
      title: "Opening Profile",
      description: "Loading detailed profile...",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Alumni Directory</h1>
          <p className="text-muted-foreground">
            Connect with our global network of alumni across industries and locations
          </p>
        </div>

        <AlumniList
          alumni={mockAlumni}
          onConnect={handleConnect}
          onMessage={handleMessage}
          onViewProfile={handleViewProfile}
        />
      </main>
      <Footer />
    </div>
  )
}
